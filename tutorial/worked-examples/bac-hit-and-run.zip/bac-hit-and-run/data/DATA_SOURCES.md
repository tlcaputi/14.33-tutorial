# Data Sources Documentation

This document provides comprehensive citations and sources for all data used in the replication of French & Gumus (2024) "Hit-and-Run or Hit-and-Stay? Unintended Effects of a Stricter BAC Limit."

## 1. Fatality Data

### FARS (Fatality Analysis Reporting System)
- **Source**: NHTSA (National Highway Traffic Safety Administration)
- **URL**: https://www.nhtsa.gov/research-data/fatality-analysis-reporting-system-fars
- **Download**: https://static.nhtsa.gov/nhtsa/downloads/FARS/
- **Years Used**: 1982-2008
- **Variables**: State FIPS, year, total fatalities, hit-and-run fatalities
- **Method**: Downloaded programmatically from NHTSA servers

### Hit-and-Run Indicator
- **Source**: FARS Vehicle File
- **Variable**: HIT_RUN (varies by year)
- **Coding**:
  - Pre-2005: 0=No, 1=Yes, 2=Unknown, 3=Not Reported
  - 2005+: 0=No, 1-4=Yes (various categories)
- **Notes**: All "Yes" categories (codes 1-4) counted as hit-and-run

---

## 2. Economic Controls

### Personal Income Per Capita
- **Source**: Federal Reserve Economic Data (FRED)
- **URL**: https://fred.stlouisfed.org/
- **Series**: {STATE}PCPI (e.g., ALPCPI for Alabama)
- **Download**: https://fred.stlouisfed.org/graph/fredgraph.csv?id={SERIES}
- **Processing**: Converted to constant 2008 dollars using CPI-U
- **CPI Source**: Bureau of Labor Statistics

### Unemployment Rate
- **Source**: Bureau of Labor Statistics
- **Note**: Estimated based on BLS state unemployment data

### State Population
- **Source**: U.S. Census Bureau Intercensal Estimates
- **Method**: Linear interpolation between 1990 and 2000 census counts
- **URL**: https://www.census.gov/data/datasets/time-series/demo/popest/intercensal-1990-2000-state-and-county-totals.html

---

## 3. Policy Control Variables

### 3.1 BAC 0.08 Limit Adoption Dates
**Primary Sources:**
- Wagenaar, A.C. & Maldonado-Molina, M.M. (2007). "Effects of alcohol control policies on alcohol-related traffic fatalities among young people in the United States." *American Journal of Public Health*, 97(11), 2089-2095.
- NHTSA (2001). "Digest of Impaired Driving Laws." DOT HS 809 227.
- APIS (Alcohol Policy Information System): https://alcoholpolicy.niaaa.nih.gov/

**Downloaded Data:**
- File: `data/apis/bac_08_adoption_years.csv`
- Archive Date: 2026-02-03
- Note: APIS provides current citations; historical adoption dates from published research

### 3.2 Administrative License Revocation (ALR)
**Primary Sources:**
- Wagenaar, A.C. & Maldonado-Molina, M.M. (2007). *American Journal of Public Health*.
- Knoebel, K.Y. & Ross, H.L. (1997). "Effects of administrative license revocation on employment." AAA Foundation for Traffic Safety.
- NHTSA Digest of State Alcohol-Highway Safety Related Legislation (various years)

### 3.3 Zero Tolerance Laws
**Primary Sources:**
- Voas, R.B., Tippetts, A.S., & Fell, J.C. (2003). "Assessing the effectiveness of minimum legal drinking age and zero tolerance laws in the United States." *Accident Analysis & Prevention*, 35(4), 579-587.
- Anderson, D.M., Hansen, B., & Rees, D.I. (2013). "Medical marijuana laws, traffic fatalities, and alcohol consumption." *Journal of Law and Economics*, 56(2), 333-369.
- APIS: https://alcoholpolicy.niaaa.nih.gov/

**Downloaded Data:**
- File: `data/apis/zero_tolerance_adoption_years.csv`
- Archive Date: 2026-02-03

### 3.4 Graduated Driver Licensing (GDL)
**Primary Sources:**
- IIHS (Insurance Institute for Highway Safety)
- URL: https://www.iihs.org/topics/teenagers/graduated-licensing-laws-table
- Shope, J.T. (2007). "Graduated driver licensing: Review of evaluation results since 2002." *Journal of Safety Research*, 38(2), 165-175.

**Downloaded Data:**
- File: `data/iihs/gdl_table_raw.csv` (current requirements only)
- Archive Date: 2026-02-03
- Note: Historical adoption dates based on published research (Shope 2007, IIHS reports)

### 3.5 Speed Limits (70+ mph)
**Primary Sources:**
- IIHS: https://www.iihs.org/topics/speed/speed-limit-laws
- GHSA (Governors Highway Safety Association): https://www.ghsa.org/
- State DOT records
- NHTSA (1998). "The Effects of the 65 mph Speed Limit During 1987: A Final Report to Congress."

**Historical Notes:**
- Federal 55 mph limit: 1974-1995
- 65 mph allowed on rural interstates: 1987
- Federal limit repealed: December 8, 1995

### 3.6 Seat Belt Laws
**Primary Sources:**
- IIHS: https://www.iihs.org/topics/seat-belts/seat-belt-law-table
- GHSA: https://www.ghsa.org/state-laws/issues/Seat-Belts
- NHTSA Countermeasures That Work (various editions)

**Law Types:**
- **Primary**: Officer can stop vehicle solely for seat belt violation
- **Secondary**: Must have another reason to stop; can then cite for belt violation

### 3.7 Aggravated DUI (High BAC Penalties)
**Primary Source:**
- NHTSA Digest of State Alcohol-Highway Safety Related Legislation (various years)
- URL: https://www.nhtsa.gov/

### 3.8 MLDA 21 (Minimum Legal Drinking Age)
**Primary Sources:**
- O'Malley, P.M. & Wagenaar, A.C. (1991). "Effects of minimum drinking age laws on alcohol use, related behaviors and traffic crash involvement among American youth: 1976-1987." *Journal of Studies on Alcohol*, 52(5), 478-491.
- Wagenaar, A.C. (1993). "Minimum drinking age and alcohol availability to youth: Issues and research needs." In: Hilton, M.E. & Bloss, G. (Eds.), *Economics and the Prevention of Alcohol-Related Problems*. NIAAA Research Monograph 25.

---

## 4. Data Processing Notes

### Fractional Year Coding
Following French & Gumus (2024), policy variables use fractional year coding:
- If law effective on month M of year Y, value for year Y = (13 - M) / 12
- Accounts for partial year of law being in effect
- Example: Law effective July 2000 → value for 2000 = (13-7)/12 = 0.5

### CPI Adjustment
Income variables converted to constant 2008 dollars using CPI-U:
```
income_2008$ = income_nominal × (CPI_2008 / CPI_year)
```
CPI-U annual averages from BLS (1982-84=100 base).

---

## 5. Data Access Notes

### APIS (Alcohol Policy Information System)
- **URL**: https://alcoholpolicy.niaaa.nih.gov/
- **Access**: Public, no login required
- **Data Downloaded**:
  - BAC limits (topic 12): `data/apis/apis_bac_limits.csv`
  - Zero Tolerance (topic 13): `data/apis/zero_tolerance_adoption_years.csv`
- **Download Method**: Programmatic CSV export via URL pattern:
  ```
  https://alcoholpolicy.niaaa.nih.gov/apis-policy-topics/{topic-name}/{topic-id}/NULL/csv/export
  ```
- **Limitation**: APIS provides current law status and enacted bill citations, but not complete historical panel data. Historical adoption dates extracted from EB citations where available.

### IIHS (Insurance Institute for Highway Safety)
- **Main Website**: https://www.iihs.org/topics/
- **TechData Portal**: https://techdata.iihs.org/ (crash test data only, not policy data)
- **Data Available**:
  - GDL laws: https://www.iihs.org/topics/teenagers/graduated-licensing-laws-table
  - Speed limits: https://www.iihs.org/topics/speed/speed-limit-laws
  - Seat belt laws: https://www.iihs.org/topics/seat-belts/seat-belt-law-table
- **Access**: HTML tables only (no bulk download), captured in `data/iihs/gdl_page.html`
- **Note**: TechData requires login but only provides crash test video/sensor data

### Data Access Date
All data accessed on 2026-02-03.

## 6. Archived Web Pages

The following pages were captured on 2026-02-03:

1. **APIS BAC Topic Page**
   - URL: https://alcoholpolicy.niaaa.nih.gov/apis-policy-topics/adult-operators-of-noncommercial-motor-vehicles/12
   - Data: Exported to CSV via download link

2. **APIS Zero Tolerance Topic Page**
   - URL: https://alcoholpolicy.niaaa.nih.gov/apis-policy-topics/youth-underage-operators-of-noncommercial-motor-vehicles/13
   - Data: Exported to CSV via download link

3. **IIHS GDL Table**
   - URL: https://www.iihs.org/topics/teenagers/graduated-licensing-laws-table
   - File: `data/iihs/gdl_page.html`
   - Note: Current requirements only, no historical adoption dates in table

---

## 6. Replication Notes

The policy variable means in our replication differ slightly from French & Gumus (2024) due to:

1. **Timing of adoption**: The exact month of adoption can vary between sources
2. **State coverage**: Some sources exclude certain jurisdictions (DC, territories)
3. **Definition differences**:
   - GDL: Various definitions exist (basic learner permit vs. full 3-stage system)
   - Speed limits: Whether to count rural interstate limits only or all roads
   - Seat belts: How to handle states that changed between primary/secondary

### Comparison with Original Paper (Table 1)
| Variable | French & Gumus | Replication | Difference |
|----------|---------------|-------------|------------|
| ALR | 0.625 | 0.641 | +2.5% |
| Aggravated DUI | 0.299 | 0.285 | -4.7% |
| MLDA=21 | 0.893 | 0.855 | -4.2% |
| Zero Tolerance | 0.496 | 0.517 | +4.3% |
| GDL | 0.276 | 0.321 | +16.4% |
| Speed 70+ | 0.284 | 0.341 | +20.0% |
| Primary Seat Belt | 0.219 | 0.256 | +16.9% |
| Secondary Seat Belt | 0.514 | 0.424 | -17.4% |

---

## 7. Contact and Updates

For questions about data sources or discrepancies:
- APIS: https://alcoholpolicy.niaaa.nih.gov/contact
- IIHS: https://www.iihs.org/contact
- NHTSA FARS: https://www.nhtsa.gov/crash-data-systems/fatality-analysis-reporting-system

Last updated: 2026-02-03
