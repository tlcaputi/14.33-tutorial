# BAC Hit-and-Run Replication: Table 2 Format Fix

**Date:** 2026-02-04
**Status:** Complete

## Problem Solved

The replicated Table 2 (Table 8 in report) did not match the format of the original Table 2 (Table 7) from French & Gumus (2024). Specifically:

1. **Missing columns**: Original had 4 columns (3), (4), (5), (6); replicated only had 2
2. **Missing control variables**: Replicated table was missing most coefficient rows
3. **Missing standard errors**: Control variables didn't show standard errors

## Solution Implemented

### 1. Updated `estimate_negbin_did()` function (lines ~828-912)

Added `include_alr_aggdui` parameter to run two model specifications:
- `include_alr_aggdui=False`: Excludes ALR and Aggravated DUI (columns 3, 5)
- `include_alr_aggdui=True`: Includes all controls (columns 4, 6)

```python
def estimate_negbin_did(df, outcome='hr_fatalities', include_alr_aggdui=True):
    # ...
    if include_alr_aggdui:
        policy_cols = ['alr', 'zero_tolerance', 'primary_seatbelt', 'secondary_seatbelt',
                       'mlda21', 'gdl', 'speed_70', 'aggravated_dui']
    else:
        policy_cols = ['zero_tolerance', 'primary_seatbelt', 'secondary_seatbelt',
                       'mlda21', 'gdl', 'speed_70']
```

### 2. Updated main estimation code (lines ~1744-1765)

Now runs 4 NB regressions to match original paper:
```python
nb_hr_3 = estimate_negbin_did(df, outcome='hr_fatalities', include_alr_aggdui=False)
nb_hr_4 = estimate_negbin_did(df, outcome='hr_fatalities', include_alr_aggdui=True)
nb_nhr_5 = estimate_negbin_did(df, outcome='nhr_fatalities', include_alr_aggdui=False)
nb_nhr_6 = estimate_negbin_did(df, outcome='nhr_fatalities', include_alr_aggdui=True)
```

### 3. Updated `generate_latex_report()` signature (line ~1112)

Changed to accept 4 NB results:
```python
def generate_latex_report(df, coef_df_hr, coef_df_nhr, did_results_hr, did_results_nhr,
                         nb_hr_3=None, nb_hr_4=None, nb_nhr_5=None, nb_nhr_6=None):
```

### 4. Added helper functions (lines ~1020-1038)

- `_format_irr_cell(irr, se)`: Formats IRR with significance stars
- `extract_irrs(nb_result, prefix)`: Extracts all IRRs from a model

### 5. Rewrote `_build_replicated_table2()` (lines ~1041-1120)

Now creates 4-column table matching original format exactly:
- Columns (3), (4) for Hit-and-run
- Columns (5), (6) for Non-hit-and-run
- ALR and Aggravated DUI only appear in columns (4) and (6)
- All rows include IRRs with significance stars and standard errors

## Files Modified

- `generate_report.py`: Main analysis script with all changes above

## Current Output

Table 8 (Replicated Table 2) now has:
- **4 columns**: (3), (4), (5), (6) matching original
- **11 variable rows** (each with IRR and SE):
  1. Illegal per se at .08 BAC
  2. Administrative license revocation (cols 4, 6 only)
  3. Aggravated DUI (cols 4, 6 only)
  4. Minimum legal drinking age=21
  5. Zero tolerance law
  6. Graduated driver-licensing
  7. Speed limit ≥70mph
  8. Seat belt law - Primary
  9. Seat belt law - Secondary
  10. Unemployment rate
  11. Ln(Real income per capita)
- **Footer rows**: Pre-law mean, State FE, Year FE, State trends

## How to Regenerate Report

```bash
cd "/Users/theo/MIT Dropbox/Theodore Caputi/job-market/gh-website/teaching/14.33/tutorial/worked-examples/bac-hit-and-run"
python generate_report.py
cd output
pdflatex bac_hitrun_report.tex
pdflatex bac_hitrun_report.tex  # Run twice for references
open bac_hitrun_report.pdf
```

## Key Results Comparison

| Variable | Original (4) | Replicated (4) |
|----------|--------------|----------------|
| .08 BAC IRR (HR) | 1.083** | 1.100** |
| .08 BAC IRR (Non-HR) | 0.999 | 1.010 |

The replication qualitatively confirms the main finding: .08 BAC laws increase hit-and-run fatalities (~10%) while having no significant effect on non-hit-and-run fatalities.
