# BAC Hit-and-Run Replication - Current State

**Last Updated:** 2026-02-04
**Status:** Complete and functional

## Overview

This project replicates French & Gumus (2024) "Hit-and-Run or Hit-and-Stay? The Effect of Stricter BAC Laws on Fatal Traffic Crashes" for MIT 14.33 tutorial on applied econometrics.

## What Works

1. **Data Pipeline**: All data sources are programmatically pulled and documented
2. **Descriptive Statistics**: Table 1 replication matches closely (6 of 8 policy variables within 5%)
3. **Event Study**: TWFE event study plots for HR and non-HR fatalities
4. **Main Regression**: 4-column negative binomial Table 2 matching original format
5. **Report Generation**: Full LaTeX report compiles successfully

## Project Structure

```
bac-hit-and-run/
├── generate_report.py          # Main analysis script (all estimation + report)
├── data/
│   ├── raw/                    # Cached raw data
│   │   ├── fars_*.csv          # FARS fatality data by year
│   │   ├── bac08_adoption_dates.csv
│   │   └── state_unemployment.csv
│   ├── apis/                   # APIS alcohol policy data
│   │   ├── bac_limits_extract/ # BAC limit CSVs
│   │   └── zero_tolerance_adoption_years.csv
│   ├── iihs/                   # IIHS scraped data
│   │   ├── seatbelt_parsed.json
│   │   ├── gdl_parsed.json
│   │   └── speed_current.json
│   └── DATA_SOURCES.md         # Full documentation of all data sources
├── output/
│   ├── bac_hitrun_report.tex   # Generated LaTeX
│   ├── bac_hitrun_report.pdf   # Final PDF report
│   └── *.png                   # Event study figures
└── .CHANGELOG/
    └── 2026-02-04_bac_replication_table2_fix.md
```

## Key Functions in generate_report.py

| Function | Lines | Purpose |
|----------|-------|---------|
| `load_fars_data()` | ~100-200 | Load FARS fatality counts |
| `get_policy_controls()` | ~420-600 | Build policy variable panel |
| `estimate_event_study()` | ~300-380 | TWFE event study estimation |
| `estimate_negbin_did()` | ~828-912 | Negative binomial regression |
| `_build_replicated_table2()` | ~1041-1120 | Generate LaTeX Table 8 |
| `generate_latex_report()` | ~1112-1700 | Full report generation |

## Data Sources

| Variable | Source | Notes |
|----------|--------|-------|
| Fatalities | FARS/NHTSA | 1982-2008 |
| .08 BAC dates | APIS | Effective dates by state |
| ALR | APIS | Administrative license revocation |
| Zero tolerance | APIS | <21 BAC laws |
| Seatbelt laws | IIHS | Primary/secondary enforcement |
| GDL | IIHS | Graduated driver licensing |
| Speed limits | IIHS | ≥70mph indicator |
| Unemployment | BLS via FRED | State-level rates |
| Income per capita | BEA via FRED | Real dollars |

## Known Limitations

1. **GDL variable**: +16.4% difference from original (IIHS shows current laws, not historical adoption)
2. **Speed 70+**: +20.0% difference (same issue as GDL)
3. **No state trends**: Original uses state-specific linear trends; we only use state/year FE
4. **Conditional vs unconditional NB**: Original uses conditional fixed-effects; we use unconditional

## Replication Results

### Main Finding (Confirmed)
- **Hit-and-run fatalities increase ~10%** after .08 BAC adoption (original: +8.3%)
- **Non-hit-and-run fatalities: no significant effect** (original: -0.1%)

### Table 1 (Descriptive Statistics)
| Variable | Original | Replicated | Diff |
|----------|----------|------------|------|
| HR Fatalities | 29.452 | 28.871 | -2.0% |
| Non-HR Fatalities | 803.122 | 796.396 | -0.8% |
| .08 BAC | 0.354 | 0.352 | -0.6% |
| ALR | 0.705 | 0.699 | -0.9% |
| Zero Tolerance | 0.637 | 0.633 | -0.6% |
| Primary Seatbelt | 0.219 | 0.218 | -0.3% |
| Secondary Seatbelt | 0.514 | 0.514 | 0.0% |
| Unemployment | 5.693 | 5.700 | +0.1% |

## How to Run

```bash
# Generate report
cd "/Users/theo/MIT Dropbox/Theodore Caputi/job-market/gh-website/teaching/14.33/tutorial/worked-examples/bac-hit-and-run"
python generate_report.py

# Compile PDF
cd output
pdflatex bac_hitrun_report.tex
pdflatex bac_hitrun_report.tex
open bac_hitrun_report.pdf
```

## Recent Changes (2026-02-04)

Fixed Table 8 (Replicated Table 2) to match Table 7 (Original Table 2):
- Added 4 columns (3), (4), (5), (6) instead of 2
- Added all control variable coefficients with standard errors
- ALR and Aggravated DUI now only appear in columns (4) and (6)

See `.CHANGELOG/2026-02-04_bac_replication_table2_fix.md` for details.

## For New Agents

**Start here:**
1. Read this file for overview
2. Read `data/DATA_SOURCES.md` for data documentation
3. Read `.CHANGELOG/` for recent changes
4. The main script `generate_report.py` is self-contained

**Key context:**
- This is a **teaching example** for MIT 14.33 Applied Econometrics
- Goal is to demonstrate replication workflow, not perfect reproduction
- All data should be pulled programmatically where possible
- Report format should match original paper's tables closely
