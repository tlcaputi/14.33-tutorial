# 01_descriptive_table.R
# Create descriptive statistics table

cat("Running 01_descriptive_table.R...\n")

pacman::p_load(data.table, modelsummary)

panel <- fread(file.path(root, "build/output/analysis_panel.csv"))

# Create group column
panel[, ever_treated := !is.na(adoption_year)]
panel[, group := fifelse(
  !ever_treated, "Untreated",
  fifelse(post_treated == 1, "Treated x Post", "Treated x Pre")
)]

# Variables for the table
vars <- c("fatal_crashes", "serious_crashes", "total_crashes",
          "fatal_share", "population", "median_income", "pct_urban")

# Create output directory
dir.create(file.path(root, "analysis/output/tables"), showWarnings = FALSE, recursive = TRUE)

# Create publication-quality table with datasummary
datasummary(
  fatal_crashes + serious_crashes + total_crashes +
    fatal_share + population + median_income + pct_urban ~
    group * (Mean + SD),
  data = panel,
  fmt = 2,
  output = file.path(root, "analysis/output/tables/descriptive_table.tex")
)

cat("\n  Saved descriptive_table.tex\n")
