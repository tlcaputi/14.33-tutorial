# 02_dd_regression.R
# Difference-in-differences regression analysis

cat("Running 02_dd_regression.R...\n")

pacman::p_load(data.table, fixest)

panel <- fread(file.path(root, "build/output/analysis_panel.csv"))

# Col 1: Main result
m1 <- feols(fatal_crashes ~ post_treated | state_fips + year,
            data = panel, vcov = ~state_fips)

# Col 2: With controls
m2 <- feols(fatal_crashes ~ post_treated + log_pop + median_income
            | state_fips + year,
            data = panel, vcov = ~state_fips)

# Col 3: South only
m3 <- feols(fatal_crashes ~ post_treated + log_pop | state_fips + year,
            data = panel[region == "South"], vcov = ~state_fips)

# Col 4: Non-South
m4 <- feols(fatal_crashes ~ post_treated + log_pop | state_fips + year,
            data = panel[region != "South"], vcov = ~state_fips)

# Col 5: Serious crashes as outcome
m5 <- feols(serious_crashes ~ post_treated + log_pop | state_fips + year,
            data = panel, vcov = ~state_fips)

# Create output directory
dir.create(file.path(root, "analysis/output/tables"), showWarnings = FALSE, recursive = TRUE)

# Export professional table
etable(
  m1, m2, m3, m4, m5,
  tex = TRUE, file = file.path(root, "analysis/output/tables/dd_results.tex"), replace = TRUE,
  headers = list(
    ":_sym:" = c("(1)", "(2)", "(3)", "(4)", "(5)")
  ),
  style.tex = style.tex(
    depvar.title = "Dep. Var.:",
    fixef.title = "\\midrule",
    yesNo = c("Yes", ""),
    stats.title = "\\midrule"
  ),
  fitstat = ~ n + r2 + wr2,
  dict = c(
    fatal_crashes = "Fatal Crashes",
    serious_crashes = "Serious Crashes",
    post_treated = "Treat x Post",
    log_pop = "Log(Population)",
    median_income = "Median Income"
  ),
  se.below = TRUE, depvar = TRUE
)

# Print results
cat("\nMain DD Results:\n")
print(summary(m1))

cat("\n  Saved dd_results.tex\n")
